package com.tweetapp.SocialMedia.TweetApp.daoImpl;

import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tweetapp.SocialMedia.TweetApp.Util.ConnectionHandler;
import com.tweetapp.SocialMedia.TweetApp.dao.UserRegisterDao;

import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;

public class RegisterDaoImpl implements UserRegisterDao {

	UserRegisterDao userRegister;
	public Connection con = null;
	public PreparedStatement ps = null;
	private final static String RegisterUser = "insert into user(firstName,lastName,gender,dob,email,password) values(?,?,?,?,?,?)";
	private final static String AllUser = "select * from user where status=?";

	public void userRegister(RegisterDto data) throws IOException {

		try {

			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(RegisterUser);

			ps.setString(1, data.getFirstName());
			ps.setString(2, data.getLastName());
			ps.setString(3, data.getGender());
			ps.setString(4, data.getDob());
			ps.setString(5, data.getEmail());
			ps.setString(6, data.getPassword());
			ps.executeUpdate();
			System.out.println("Registration Sucessfull!");
		}

		catch (SQLException e) {

			e.printStackTrace();
			;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void viewAllUser() throws IOException {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(AllUser);
			ps.setString(1, "TRUE");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				System.out.println(rs.getString(5));
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

}
