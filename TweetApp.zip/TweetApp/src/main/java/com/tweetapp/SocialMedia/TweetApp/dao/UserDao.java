package com.tweetapp.SocialMedia.TweetApp.dao;

import java.io.IOException;

public interface UserDao {
	
	public boolean login(String email, String password) throws IOException;
	
	public boolean forgetPassword(String email,String password,String dob) throws IOException;
	
	public void logout(String email) throws IOException;

}
