package com.tweetapp.SocialMedia.TweetApp.daoImpl;

import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tweetapp.SocialMedia.TweetApp.Util.ConnectionHandler;
import com.tweetapp.SocialMedia.TweetApp.dao.UserDao;

public class UserDaoImpl implements UserDao {

	public Connection con = null;
	public PreparedStatement ps = null;
	private final static String userquery = "select * from user where email=?";
	private final static String passsquery = "update user set password=?  where email=?";
	private final static String updatequery = "update user set status=? where email=?";

	public boolean login(String email, String password) throws IOException {

		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(userquery);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			rs.next();

			if (rs.getString(6).equalsIgnoreCase(password)) {
				System.out.println("Sucessfully logged in!");
				ps = con.prepareStatement(updatequery);
				ps.setString(1, "TRUE");
				ps.setString(2, email);
				ps.executeUpdate();
				return true;
			}
		}

		catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
		System.out.println("Invalid Credentials");

		return false;
	}

	public boolean forgetPassword(String email, String password, String dob) throws IOException {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(userquery);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			rs.next();
			if (rs != null) {
				if (rs.getString(4).equals(dob)) {
					ps = con.prepareStatement(passsquery);
					ps.setString(1, password);
					ps.setString(2, email);
					ps.executeUpdate();
					return true;
				}

			}

		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e1) {

			e1.printStackTrace();
		}

		return false;
	}

	public void logout(String email) throws IOException {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(updatequery);
			ps.setString(1, "false");
			ps.setString(2, email);
			ps.executeUpdate();
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e1) {

			e1.printStackTrace();
		}
	}

}
