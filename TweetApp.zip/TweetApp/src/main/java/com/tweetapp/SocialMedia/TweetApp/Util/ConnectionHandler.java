package com.tweetapp.SocialMedia.TweetApp.Util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {

	public static Connection getConnection() throws IOException, ClassNotFoundException, SQLException {

		Properties property = new Properties();
		Connection connection;

		BufferedInputStream bufferedInputStream = (BufferedInputStream) ConnectionHandler.class.getClassLoader()
				.getResourceAsStream("db.properties");
		property.load(bufferedInputStream);
		String driver = (String) property.get("driver");
		Class.forName(driver);
		String url = (String) property.get("connection-url");
		String user = (String) property.get("user");

		String password = (String) property.get("password");
		connection = DriverManager.getConnection(url, user, password);
		return connection;

	}
}
